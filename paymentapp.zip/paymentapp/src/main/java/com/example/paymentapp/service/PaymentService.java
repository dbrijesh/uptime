package com.example.paymentapp.service;

import com.example.paymentapp.model.PaymentStatus;
import com.example.paymentapp.repository.PaymentStatusRepository;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
public class PaymentService {

    @Autowired
    private PaymentStatusRepository paymentStatusRepository;

    public List<PaymentStatus> processPayments(MultipartFile file, String paymentType) {
        List<PaymentStatus> statuses = new ArrayList<>();

        try (Reader reader = new InputStreamReader(file.getInputStream())) {
            CSVParser csvParser = new CSVParser(reader, CSVFormat.DEFAULT);
            int size = 0;
            for (CSVRecord csvRecord : csvParser) {
            	if (size!= 0) {
            	System.out.println(csvRecord.get(0) + " " + csvRecord.get(1) + " " + csvRecord.get(2));
                String recordId = csvRecord.get(0);
                String vendor = csvRecord.get(1);
                Double paymentAmount = Double.valueOf(csvRecord.get(2));
                PaymentStatus status = makePayment(recordId, vendor, paymentAmount,paymentType);
                statuses.add(status);
                paymentStatusRepository.save(status);
            	}
            	size++;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return statuses;
    }

    private PaymentStatus makePayment(String recordId, String vendor, Double paymentAmount,String paymentType) {
        return new PaymentStatus(recordId, "SUCCESS", LocalDateTime.now(), paymentAmount,vendor);
    }

    public List<PaymentStatus> getAllPaymentStatuses() {
        return paymentStatusRepository.findAll();
    }
}
