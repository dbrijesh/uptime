package com.example.paymentapp.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
public class PaymentStatus {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String recordId;
    private String status;
    private LocalDateTime date;
    private String vendor;
    private Double paymentAmount;

    public Double getPaymentAmount() {
		return paymentAmount;
	}

	public void setPaymentAmount(Double paymentAmount) {
		this.paymentAmount = paymentAmount;
	}

	public PaymentStatus() {}

    public PaymentStatus(String recordId, String status, LocalDateTime date,Double paymentAmount, String vendor) {
        this.recordId = recordId;
        this.status = status;
        this.date = date;
        this.paymentAmount = paymentAmount;
        this.vendor = vendor;
    }

    public String getRecordId() {
        return recordId;
    }

    public void setRecordId(String recordId) {
        this.recordId = recordId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDateTime getDate() {
        return date;
    }

    public void setDate(LocalDateTime date) {
        this.date = date;
    }

    public String getVendor() {
        return vendor;
    }

    public void setVendor(String vendor) {
        this.vendor = vendor;
    }

    // Getters and setters...
}
