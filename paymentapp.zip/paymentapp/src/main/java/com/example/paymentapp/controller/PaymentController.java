package com.example.paymentapp.controller;

import com.example.paymentapp.model.PaymentStatus;
import com.example.paymentapp.service.PaymentService;
import org.springframework.http.HttpStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api")
public class PaymentController {

	@Autowired
	private PaymentService paymentService;

	@PostMapping("/upload")
	public ResponseEntity<List<String>> handleFileUpload(@RequestParam("files") List<MultipartFile> files,
			@RequestParam("paymentTypes") List<String> paymentTypes) {
		List<String> statuses = new ArrayList<>();

		try {
			for (int i = 0; i < files.size(); i++) {
				MultipartFile file = files.get(i);
				String paymentType = paymentTypes.get(i);
				List<PaymentStatus> status = paymentService.processPayments(file, paymentType);
				if (status!= null) {
					statuses.add("Success");
				}else {
					statuses.add("Failed");
				}
			}
			return new ResponseEntity<>(statuses, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<>(List.of("Failed to process files"), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@GetMapping("/statuses")
	public List<PaymentStatus> getAllPaymentStatuses() {
		return paymentService.getAllPaymentStatuses();
	}
}
