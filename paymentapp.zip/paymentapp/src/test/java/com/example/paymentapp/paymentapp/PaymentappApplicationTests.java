package com.example.paymentapp.paymentapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaymentappApplicationTests {

	@Test
	void contextLoads() {
	}

}
