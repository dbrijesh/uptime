import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import PaymentUploader from './components/PaymentUploader';
import PaymentStatusPage from './components/PaymentStatusPage';

function App() {
  return (
    <Router>
      <div className="container">
        <Routes>
          <Route path="/" element={<PaymentUploader />} />
          <Route path="/payment-status" element={<PaymentStatusPage />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
