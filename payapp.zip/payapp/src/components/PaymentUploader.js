import React, { useState } from 'react';
import axios from 'axios';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Link } from 'react-router-dom';

const PaymentUploader = () => {
  const [paymentType, setPaymentType] = useState('');
  const [uploadedFiles, setUploadedFiles] = useState([]);
  const [recordCount, setRecordCount] = useState(0);
  const [totalAmount, setTotalAmount] = useState(0);
  const [status, setStatus] = useState('');
  const [activeTab, setActiveTab] = useState('summary');

  const handlePaymentTypeChange = (event) => {
    setPaymentType(event.target.value);
  };

  const handleFileUpload = (event) => {
    const files = Array.from(event.target.files || event.dataTransfer.files);
    if (!paymentType) {
      alert("Please select a payment type before uploading files.");
      return;
    }
    const newUploadedFiles = files.map(file => ({
      file,
      paymentType
    }));
    setUploadedFiles([...uploadedFiles, ...newUploadedFiles]);

    let totalRecords = 0;
    let totalAmount = 0;

    files.forEach((file) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const lines = e.target.result.split('\n');
        const amountIndex = 2; // Amount is the third field in CSV (index 2)
        const numOfRecords = lines.length - 1; // Excluding header row
        totalRecords += numOfRecords;

        for (let i = 1; i < lines.length; i++) {
          const fields = lines[i].split(',');
          if (fields[amountIndex]) {
            totalAmount += parseFloat(fields[amountIndex]) || 0;
          }
        }

        setRecordCount(totalRecords);
        setTotalAmount(totalAmount);
      };
      reader.readAsText(file);
    });
  };

  const handleDrop = (event) => {
    event.preventDefault();
    handleFileUpload(event);
  };

  const handleDragOver = (event) => {
    event.preventDefault();
  };

  const handleSubmit = async () => {
    if (uploadedFiles.length > 0) {
      const formData = new FormData();
      uploadedFiles.forEach(({ file, paymentType }) => {
        formData.append('files', file);
        formData.append('paymentTypes', paymentType);
      });

      try {
        const response = await axios.post('http://localhost:8080/api/upload', formData, {
          headers: { 'Content-Type': 'multipart/form-data' }
        });

        setStatus('Upload successful!');
        console.log('Response:', response.data);

      } catch (error) {
        console.error('Error during upload:', error);
        setStatus('Error during upload.');
      }
    } else {
      alert("Please upload CSV files.");
    }
  };

  const handleClearAll = () => {
    setPaymentType('');
    setUploadedFiles([]);
    setRecordCount(0);
    setTotalAmount(0);
    setStatus('');
  };

  return (

      <div className="card p-4 shadow-sm">
        <h4 className="mb-4 text-center" style={{ color: 'green', fontWeight: 'bold' }}>Payment Manager Upload</h4>

        <h5 className="mb-4 text-center">Type of File You Are Uploading</h5>
        <div className="form-group mb-4">
          <div className="d-flex justify-content-center">
            <div className="form-check form-check-inline mr-5">
              <input
                className="form-check-input"
                type="radio"
                name="paymentType"
                id="NACHA"
                value="NACHA"
                checked={paymentType === 'NACHA'}
                onChange={handlePaymentTypeChange}
                style={{ accentColor: 'green' }}
              />
              <label className="form-check-label ml-2" htmlFor="NACHA">NACHA</label>
            </div>
            <div className="form-check form-check-inline">
              <input
                className="form-check-input"
                type="radio"
                name="paymentType"
                id="ISO"
                value="ISO"
                checked={paymentType === 'ISO'}
                onChange={handlePaymentTypeChange}
                style={{ accentColor: 'green' }}
              />
              <label className="form-check-label ml-2" htmlFor="ISO">ISO</label>
            </div>
          </div>
        </div>
        <div
          className="form-group border p-4 mb-4 bg-light rounded"
          onDrop={handleDrop}
          onDragOver={handleDragOver}
          style={{ borderStyle: 'dashed', textAlign: 'center' }}
        >
          <label htmlFor="csvFile" className="d-block">Drag and Drop CSV Files Here or Click to Upload</label>
          <input
            type="file"
            id="csvFile"
            accept=".csv"
            multiple
            className="form-control-file mt-3"
            onChange={handleFileUpload}
          />
        </div>
        <ul className="list-unstyled mb-4 text-center">
          {uploadedFiles.map((file, index) => (
            <li key={index} className="text-success">
              {file.file.name} ({file.paymentType})
            </li>
          ))}
        </ul>
        <div className="d-flex justify-content-center mb-4">
        <div className="form-check form-check-inline">
        <button className="btn btn-secondary" onClick={handleClearAll}>Clear All</button>
          </div>
          <div className="form-check form-check-inline">
          <button className="btn btn-success mr-3" onClick={handleSubmit}>Submit</button>
         
          </div>
        </div>

        <ul className="nav nav-tabs justify-content-center mb-4">
          <li className="nav-item">
            <button
              className={`nav-link ${activeTab === 'summary' ? 'active' : ''}`}
              onClick={() => setActiveTab('summary')}
            >
              Summary
            </button>
          </li>
          <li className="nav-item">
            <button
              className={`nav-link ${activeTab === 'status' ? 'active' : ''}`}
              onClick={() => setActiveTab('status')}
            >
              Payment Status
            </button>
          </li>
        </ul>

        {activeTab === 'summary' && (
          <div className="card p-3 mb-4">
            
            <p className="font-weight-bold mb-1">Number of Records: {recordCount}</p>
            <p className="font-weight-bold">Total Payment Amount: ${totalAmount.toFixed(2)}</p>
          </div>
        )}

        {activeTab === 'status' && (
          <div className="card p-3 mb-4">
            <h4>Payment Status</h4>
            <Link to="/payment-status" className="text-info">View Payment Status</Link>
          </div>
        )}

        <p className="mt-4 text-center">{status}</p>
      </div>
 
  );
};

export default PaymentUploader;
