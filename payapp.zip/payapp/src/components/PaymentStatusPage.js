import React, { useEffect, useState } from 'react';
import axios from 'axios';
import 'bootstrap/dist/css/bootstrap.min.css';

const PaymentStatusPage = () => {
  const [statuses, setStatuses] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:8080/api/statuses')
      .then(response => setStatuses(response.data))
      .catch(error => console.error('Error fetching payment statuses:', error));
  }, []);

  return (
    <div className="container">
      <h1>Payment Statuses</h1>
      <table className="table table-bordered">
        <thead>
          <tr>
            <th>Record ID</th>
            <th>Status</th>
            <th>Date</th>
            <th>Vendor</th>
            <th>Amount</th>
          </tr>
        </thead>
        <tbody>
          {statuses.map((status, index) => (
            <tr key={index}>
              <td>{status.recordId}</td>
              <td>{status.status}</td>
              <td>{status.date}</td>
              <td>{status.vendor}</td>
              <td>{status.paymentAmount}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default PaymentStatusPage;
